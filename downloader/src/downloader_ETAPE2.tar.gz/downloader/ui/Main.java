package downloader.ui;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

import downloader.fc.Downloader;

public class Main {
	
	public static void main(String[] args) {
		JFrame fenPrinc = new JFrame();
		JPanel babarres = new JPanel(new StackLayout());
		fenPrinc.setSize(500, 500);
		fenPrinc.setVisible(true);
		
		fenPrinc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/***********************************************************************************/
		
		ArrayList<Thread> threads = new ArrayList<Thread>();
		
//		for (int i = 0; i < args.length; i++) {
//			threads.add(new Thread());
//		}
		
		for(String url: args) {
			
			final Downloader downloader; 
			final JProgressBar barreProgression;
			
			try {
				downloader = new Downloader(url);
				barreProgression = new JProgressBar();
				babarres.add(barreProgression);
				fenPrinc.add(babarres);
			}
			catch(RuntimeException e) {
				System.err.format("skipping %s %s\n", url, e);
				continue;
			}
			System.out.format("Downloading %s:", downloader);
			
			downloader.addPropertyChangeListener(new  PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					barreProgression.setValue(downloader.getProgress());
					barreProgression.setStringPainted(true);
					barreProgression.setString(""+downloader.getProgress());
					System.out.flush();
				}
			});
		
			
			
//				filename = downloader.download();
				Thread t = new Thread(downloader);
				threads.add(t);
				t.start();
				
		}
		
		for (int i = 0; i < threads.size(); i++) {
			try {
				threads.get(i).join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		/********************************************************************************/

	}
}